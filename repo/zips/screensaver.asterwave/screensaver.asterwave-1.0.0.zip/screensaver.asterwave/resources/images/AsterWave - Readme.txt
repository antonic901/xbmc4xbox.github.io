AsterWave by Asteron

Silverwave will choose a random image within this folder as a texture.
Images can be of the following formats.

.bmp, .dds, .dib, .hdr, .jpg, .pfm, .png, .ppm, and .tga 

Most image resolutions work but powers of 2 should be better, 512x512 is recommended.

To test a texture just place it in this folder and remove the other pictures.

Enjoy!



Credits/Thanks
--------------
Thanks to Jyra (Team XBMC) for his submission liquid2cj0-1.jpg

Also thanks to XBMC's own MilkDrop visualization for some of the outlandish textures.

All photos not credited were taken gratefully from the public domain, special thanks to
Jon Sullivan - http://www.pdphoto.org


The following picture(s) included in this distribution are licensed under the GFDL
For the full GFDL text see
http://commons.wikimedia.org/wiki/Commons:GNU_Free_Documentation_License

Koh_Samui_Lipa_Noi2.jpg (modified)
http://en.wikipedia.org/wiki/Image:Koh_Samui_Lipa_Noi2.jpg by Manfred Werner (GFDL)


These photos are licensed under the Creative Commons 
For license terms see
http://creativecommons.org/licenses/ 

Esplanade sunset
http://www.flickr.com/photos/pearbiter/133448650/ by Pear Bitter (CC by-sa 2.0)

Sunset in Hawaii
http://www.flickr.com/photos/nicolala/424490412/ by GoddessNicole (CC by 2.0)


