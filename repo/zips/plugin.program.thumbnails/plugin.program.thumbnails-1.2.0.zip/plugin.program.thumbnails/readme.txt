Changelog:
~~~~~~~~~~

v1.2 (Thursday, 8 September 2011):
  - clean .dds thumbnails (thanks to rudeboyx & ocmdiaz714);
  - clean Season thumbnails correctly (thanks to ocmdiaz714);

v1.1 :
  - rewrite;
  - display clean-up report;